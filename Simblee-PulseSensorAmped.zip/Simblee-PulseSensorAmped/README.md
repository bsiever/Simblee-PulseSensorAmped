# Simblee-PulseSensorAmped
Simblee (and RFduino) library for Pulse Sensor (http://pulsesensor.com/)